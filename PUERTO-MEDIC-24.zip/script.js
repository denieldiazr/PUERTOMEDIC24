$(document).ready(function() {

    $('#caja1').hover(function(){ 
        $('#caja1').css('background','#56638b');
        $('#centro1').css('border','3px solid #939BBC');
        $('#titulo1').css('color','#fff');
        $('#titulo1').css('margin-top','15px');
        $('#icono1').css('color','#939BBC');
    },function(){ 
        $('#caja1').css('background','#F6F7F5');
        $('#centro1').css('border','25px solid #F6F7F5');
        $('#titulo1').css('color','#3a3a3a');
        $('#titulo1').css('margin-top','-15px');
        $('#icono1').css('color','#9b9b9b');
    });

    $('#caja2').hover(function(){ 
        $('#caja2').css('background','#56638b');
        $('#centro2').css('border','3px solid #939BBC');
        $('#titulo2').css('color','#fff');
        $('#titulo2').css('margin-top','15px');
        $('#icono2').css('color','#939BBC');
        
    },function(){ 
        $('#caja2').css('background','#F6F7F5');
        $('#centro2').css('border','25px solid #F6F7F5');
        $('#titulo2').css('color','#3a3a3a');
        $('#titulo2').css('margin-top','-15px');
        $('#icono2').css('color','#9b9b9b');
    });

    $('#caja3').hover(function(){ 
        $('#caja3').css('background','#56638b');
        $('#centro3').css('border','3px solid #939BBC');
        $('#titulo3').css('color','#fff');
        $('#titulo3').css('margin-top','15px');
        $('#icono3').css('color','#939BBC');
    },function(){ 
        $('#caja3').css('background','#F6F7F5');
        $('#centro3').css('border','25px solid #F6F7F5');
        $('#titulo3').css('color','#3a3a3a');
        $('#titulo3').css('margin-top','-15px');
        $('#icono3').css('color','#9b9b9b');
    });

    $('#caja4').hover(function(){ 
        $('#caja4').css('background','#56638b');
        $('#centro4').css('border','3px solid #939BBC');
        $('#titulo4').css('color','#fff');
        $('#titulo4').css('margin-top','15px');
        $('#icono4').css('color','#939BBC');
    },function(){ 
        $('#caja4').css('background','#F6F7F5');
        $('#centro4').css('border','25px solid #F6F7F5');
        $('#titulo4').css('color','#3a3a3a');
        $('#titulo4').css('margin-top','-15px');
        $('#icono4').css('color','#9b9b9b');
    });

    $('#caja5').hover(function(){ 
        $('#caja5').css('background','#56638b');
        $('#centro5').css('border','3px solid #939BBC');
        $('#titulo5').css('color','#fff');
        $('#titulo5').css('margin-top','15px');
        $('#icono5').css('color','#939BBC');
    },function(){ 
        $('#caja5').css('background','#F6F7F5');
        $('#centro5').css('border','25px solid #F6F7F5');
        $('#titulo5').css('color','#3a3a3a');
        $('#titulo5').css('margin-top','-15px');
        $('#icono5').css('color','#9b9b9b');
    });

    $('#caja6').hover(function(){ 
        $('#caja6').css('background','#56638b');
        $('#centro6').css('border','3px solid #939BBC');
        $('#titulo6').css('color','#fff');
        $('#titulo6').css('margin-top','15px');
        $('#icono6').css('color','#939BBC');
    },function(){ 
        $('#caja6').css('background','#F6F7F5');
        $('#centro6').css('border','25px solid #F6F7F5');
        $('#titulo6').css('color','#3a3a3a');
        $('#titulo6').css('margin-top','-15px');
        $('#icono6').css('color','#9b9b9b');
    });

    $('#caja7').hover(function(){ 
        $('#caja7').css('background','#56638b');
        $('#centro7').css('border','3px solid #939BBC');
        $('#titulo7').css('color','#fff');
        $('#titulo7').css('margin-top','15px');
        $('#icono7').css('color','#939BBC');
    },function(){ 
        $('#caja7').css('background','#F6F7F5');
        $('#centro7').css('border','25px solid #F6F7F5');
        $('#titulo7').css('color','#3a3a3a');
        $('#titulo7').css('margin-top','-15px');
        $('#icono7').css('color','#9b9b9b');
    });

    $('#caja8').hover(function(){ 
        $('#caja8').css('background','#56638b');
        $('#centro8').css('border','3px solid #939BBC');
        $('#titulo8').css('color','#fff');
        $('#titulo8').css('margin-top','15px');
        $('#icono8').css('color','#939BBC');
    },function(){ 
        $('#caja8').css('background','#F6F7F5');
        $('#centro8').css('border','25px solid #F6F7F5');
        $('#titulo8').css('color','#3a3a3a');
        $('#titulo8').css('margin-top','-15px');
        $('#icono8').css('color','#9b9b9b');
    });

    $('#caja9').hover(function(){ 
        $('#caja9').css('background','#56638b');
        $('#centro9').css('border','3px solid #939BBC');
        $('#titulo9').css('color','#fff');
        $('#titulo9').css('margin-top','15px');
        $('#icono9').css('color','#939BBC');
    },function(){ 
        $('#caja9').css('background','#F6F7F5');
        $('#centro9').css('border','25px solid #F6F7F5');
        $('#titulo9').css('color','#3a3a3a');
        $('#titulo9').css('margin-top','-15px');
        $('#icono9').css('color','#9b9b9b');
    });

    $('#caja10').hover(function(){ 
        $('#caja10').css('background','#56638b');
        $('#centro10').css('border','3px solid #939BBC');
        $('#titulo10').css('color','#fff');
        $('#titulo10').css('margin-top','15px');
        $('#icono10').css('color','#939BBC');
    },function(){ 
        $('#caja10').css('background','#F6F7F5');
        $('#centro10').css('border','25px solid #F6F7F5');
        $('#titulo10').css('color','#3a3a3a');
        $('#titulo10').css('margin-top','-15px');
        $('#icono10').css('color','#9b9b9b');
    });

    $('#caja11').hover(function(){ 
        $('#caja11').css('background','#56638b');
        $('#centro11').css('border','3px solid #939BBC');
        $('#titulo11').css('color','#fff');
        $('#titulo11').css('margin-top','15px');
        $('#icono11').css('color','#939BBC');
    },function(){ 
        $('#caja11').css('background','#F6F7F5');
        $('#centro11').css('border','25px solid #F6F7F5');
        $('#titulo11').css('color','#3a3a3a');
        $('#titulo11').css('margin-top','-15px');
        $('#icono11').css('color','#9b9b9b');
    });

    $('#caja12').hover(function(){ 
        $('#caja12').css('background','#56638b');
        $('#centro12').css('border','3px solid #939BBC');
        $('#titulo12').css('color','#fff');
        $('#titulo12').css('margin-top','15px');
        $('#icono12').css('color','#939BBC');
    },function(){ 
        $('#caja12').css('background','#F6F7F5');
        $('#centro12').css('border','25px solid #F6F7F5');
        $('#titulo12').css('color','#3a3a3a');
        $('#titulo12').css('margin-top','-15px');
        $('#icono12').css('color','#9b9b9b');
    });

    $('#caja13').hover(function(){ 
        $('#caja13').css('background','#56638b');
        $('#centro13').css('border','3px solid #939BBC');
        $('#titulo13').css('color','#fff');
        $('#titulo13').css('margin-top','15px');
        $('#icono13').css('color','#939BBC');
    },function(){ 
        $('#caja13').css('background','#F6F7F5');
        $('#centro13').css('border','25px solid #F6F7F5');
        $('#titulo13').css('color','#3a3a3a');
        $('#titulo13').css('margin-top','-15px');
        $('#icono13').css('color','#9b9b9b');
    });

    $('#caja14').hover(function(){ 
        $('#caja14').css('background','#56638b');
        $('#centro14').css('border','3px solid #939BBC');
        $('#titulo14').css('color','#fff');
        $('#titulo14').css('margin-top','15px');
        $('#icono14').css('color','#939BBC');
    },function(){ 
        $('#caja14').css('background','#F6F7F5');
        $('#centro14').css('border','25px solid #F6F7F5');
        $('#titulo14').css('color','#3a3a3a');
        $('#titulo14').css('margin-top','-15px');
        $('#icono14').css('color','#9b9b9b');
    });

    $('#caja15').hover(function(){ 
        $('#caja15').css('background','#56638b');
        $('#centro15').css('border','3px solid #939BBC');
        $('#titulo15').css('color','#fff');
        $('#titulo15').css('margin-top','15px');
        $('#icono15').css('color','#939BBC');
    },function(){ 
        $('#caja15').css('background','#F6F7F5');
        $('#centro15').css('border','25px solid #F6F7F5');
        $('#titulo15').css('color','#3a3a3a');
        $('#titulo15').css('margin-top','-15px');
        $('#icono15').css('color','#9b9b9b');
    });

});



function Formulario(id){
    document.getElementById("center").style.display = "flex";
    document.getElementById("especialidad").value = document.getElementById("espe"+id).innerHTML;
    document.getElementById("doctor").value = document.getElementById("nombre"+id).innerHTML;
    document.getElementById("numero").value = id;
    document.getElementById("nombres").focus();

    
}

document.getElementById('cerrar').addEventListener('click', function(){
    document.getElementById("center").style.display = "none";
});

document.addEventListener('keydown', function(event) {
    if (event.keyCode == 27) {
        document.getElementById("center").style.display = "none";
    }
  });

  function numeroDia(dia){
    if(dia == "Lunes"){
        return 0;
    }else if(dia == "Martes"){
        return 1;
    }else if(dia == "Miercoles"){
        return 2;
    }else if(dia == "Jueves"){
        return 3;
    }else if(dia == "Viernes"){
        return 4;
    }else if(dia == "Sabado"){
        return 5;
    }
    return 6;
  }

  function validar(e) {
    const dia = (new Date(e.target.value)).getDay();
    console.log(dia);
    num = document.getElementById('numero').value;
    d1 = numeroDia(document.getElementById('dias1'+num).innerHTML)
    d2 = numeroDia(document.getElementById('dias2'+num).innerHTML)
    d3 = numeroDia(document.getElementById('dias3'+num).innerHTML)
    if(isNaN(dia)){

    }else if (dia != d1 && dia != d2 && dia != d3) { 
      e.target.value = ""; 
      swal.fire('¡Error!', 
      'Solo puede elegir fechas que sean dias '+document.getElementById('dias1'+num).innerHTML+", "+
      document.getElementById('dias2'+num).innerHTML+" y "+document.getElementById('dias3'+num).innerHTML, 
      'error');
    }
  h1=0;h2=0; x=0;y=0;
    if(dia==d1){
        horas = document.getElementById("horas1"+num).innerHTML;
        dividir = horas.split("-");
        x = dividir[0].trim();
        y = dividir[1].trim();

        h1 = x.split(":")
        h2 = y.split(":")
    }else if(dia==d2){
        horas = document.getElementById("horas2"+num).innerHTML;
        dividir = horas.split("-");
        x = dividir[0].trim();
        y = dividir[1].trim();

        h1 = x.split(":")
        h2 = y.split(":")
    }else if(dia==d3){
        horas = document.getElementById("horas3"+num).innerHTML;
        dividir = horas.split("-");
        x = dividir[0].trim();
        y = dividir[1].trim();

        h1 = x.split(":")
        h2 = y.split(":")
    }
    const select =  document.getElementById('horas');
    $("#horas").find('option').not(':first').remove();
    console.log(h1[0]+" - "+h2[0]+" 3") 
    l = h1[0];
    k = parseInt(h2[0],10);
    console.log(l+"-"+k)
    for(i=l; i<=k;i++){
        const option = document.createElement('option');
        option.text=i+":00";
        option.value=i+":00";
        select.appendChild(option);
    }

  }

  /*NAV BAR STICKY*/
  var navbar = document.getElementById("navbar");
  var menu = document.getElementById("menu")

  window.onscroll = function(){
    if(window.pageYOffset > menu.offsetTop){
        navbar.classList.add("sticky")
        if(document.getElementById("Parte3").classList.contains("activar") ){
            document.getElementById("Parte3").classList.remove("activar")
            document.getElementById("Parte3").classList.add("activar2") 
        }
    }else{
        navbar.classList.remove("sticky")
        console.log("Holi")
        if(document.getElementById("Parte3").classList.contains("activar2") ){
            document.getElementById("Parte3").classList.remove("activar2") 
            document.getElementById("Parte3").classList.add("activar") 
        }
    }
  }

  document.getElementById("checke").addEventListener('click', function(){
    if(document.getElementById("Parte3").classList.contains("activar") || document.getElementById("Parte3").classList.contains("activar2") ){
      document.getElementById("Parte3").classList.remove("activar")  
      document.getElementById("Parte3").classList.remove("activar2") 
    }else if(!document.getElementById("Parte3").classList.contains("activar") && !(window.pageYOffset > menu.offsetTop)){
        document.getElementById("Parte3").classList.add("activar") 
    }else {
        document.getElementById("Parte3").classList.add("activar2") 
    }
    
});

function Cerrar(){
    document.getElementById("Parte3").classList.remove("activar")  
      document.getElementById("Parte3").classList.remove("activar2") 
}
